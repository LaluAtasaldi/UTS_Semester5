<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tb_barang extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Tb_barang_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'tb_barang/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'tb_barang/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'tb_barang/index.html';
            $config['first_url'] = base_url() . 'tb_barang/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Tb_barang_model->total_rows($q);
        $tb_barang = $this->Tb_barang_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'tb_barang_data' => $tb_barang,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('tb_barang/tb_barang_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Tb_barang_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'nama_barang' => $row->nama_barang,
		'merek' => $row->merek,
		'keadaan' => $row->keadaan,
		'ruangan' => $row->ruangan,
	    );
            $this->load->view('tb_barang/tb_barang_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_barang'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('tb_barang/create_action'),
	    'id' => set_value('id'),
	    'nama_barang' => set_value('nama_barang'),
	    'merek' => set_value('merek'),
	    'keadaan' => set_value('keadaan'),
	    'ruangan' => set_value('ruangan'),
	);
        $this->load->view('tb_barang/tb_barang_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nama_barang' => $this->input->post('nama_barang',TRUE),
		'merek' => $this->input->post('merek',TRUE),
		'keadaan' => $this->input->post('keadaan',TRUE),
		'ruangan' => $this->input->post('ruangan',TRUE),
	    );

            $this->Tb_barang_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('tb_barang'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Tb_barang_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('tb_barang/update_action'),
		'id' => set_value('id', $row->id),
		'nama_barang' => set_value('nama_barang', $row->nama_barang),
		'merek' => set_value('merek', $row->merek),
		'keadaan' => set_value('keadaan', $row->keadaan),
		'ruangan' => set_value('ruangan', $row->ruangan),
	    );
            $this->load->view('tb_barang/tb_barang_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_barang'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'nama_barang' => $this->input->post('nama_barang',TRUE),
		'merek' => $this->input->post('merek',TRUE),
		'keadaan' => $this->input->post('keadaan',TRUE),
		'ruangan' => $this->input->post('ruangan',TRUE),
	    );

            $this->Tb_barang_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('tb_barang'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Tb_barang_model->get_by_id($id);

        if ($row) {
            $this->Tb_barang_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('tb_barang'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_barang'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nama_barang', 'nama barang', 'trim|required');
	$this->form_validation->set_rules('merek', 'merek', 'trim|required');
	$this->form_validation->set_rules('keadaan', 'keadaan', 'trim|required');
	$this->form_validation->set_rules('ruangan', 'ruangan', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "tb_barang.xls";
        $judul = "tb_barang";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama Barang");
	xlsWriteLabel($tablehead, $kolomhead++, "Merek");
	xlsWriteLabel($tablehead, $kolomhead++, "Keadaan");
	xlsWriteLabel($tablehead, $kolomhead++, "Ruangan");

	foreach ($this->Tb_barang_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama_barang);
	    xlsWriteLabel($tablebody, $kolombody++, $data->merek);
	    xlsWriteLabel($tablebody, $kolombody++, $data->keadaan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->ruangan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=tb_barang.doc");

        $data = array(
            'tb_barang_data' => $this->Tb_barang_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('tb_barang/tb_barang_doc',$data);
    }

}

/* End of file Tb_barang.php */
/* Location: ./application/controllers/Tb_barang.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-07-16 08:36:53 */
/* http://harviacode.com */